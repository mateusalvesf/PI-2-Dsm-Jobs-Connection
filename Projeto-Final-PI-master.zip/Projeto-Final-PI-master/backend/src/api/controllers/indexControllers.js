module.exports = {
    indexRaiz
}

function indexRaiz(req, res) {
    res.json('Rota Raiz Encontrada!')
    console.log('Rota Raiz Encontrada!')
    
}



   

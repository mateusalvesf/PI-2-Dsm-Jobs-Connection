module.exports = {
    host: 'localhost',
    dialect: 'mysql',
    username: 'root',
    password: '210396',
    database: 'webiiorm',
    define: {
        timestamps:false,
        underscored: true,
    },
};


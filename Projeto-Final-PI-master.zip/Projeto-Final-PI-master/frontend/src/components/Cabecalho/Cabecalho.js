import React from "react";

import "./Cabecalho.css"

function Cabecalho() {
  return (
    <div className="divider">
      <h2>Projeto PI 2º DSM</h2>

    </div>
  );
}

export default Cabecalho;

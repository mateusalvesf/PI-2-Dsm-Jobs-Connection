import React from "react";
import "./Rodape.css"

function Rodape() {
  return (
    <footer class="footer mt-auto py-3 bg-light">
      <div class="container">
       <span class="text-muted">Projeto PI 2º DSM 2º Semestre</span>
        </div>
       </footer>
    // <div className="rodape">
    //   Desenvolvimento de Software Multiplataforma 

    // </div>
  );
}

export default Rodape;

import React from "react";

const TabelaHeader = () => (
    <thead>
        <tr> 
            <th scope="col"> Código </th>
            <th scope="col"> Descrição da Categoria </th>
            <th scope="col"> Inclusão </th>
            <th scope="col"> Alteração </th>
        </tr>
    </thead>
);

export default TabelaHeader;

// <th scope="col"> Código </th>


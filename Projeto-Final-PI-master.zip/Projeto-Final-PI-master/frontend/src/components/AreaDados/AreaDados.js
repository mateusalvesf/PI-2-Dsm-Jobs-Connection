import React from "react";
import "./AreaDados.css"

export default function AreaDados() {
  return (
    <div className="areaDados">
      Torne-se um Profissional
    </div>
  );
}

